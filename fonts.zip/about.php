<link rel="stylesheet" type="text/css" href="css/style.css">
<?php 
include('header.php');
echo "about";
?>
